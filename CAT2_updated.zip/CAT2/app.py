from flask import Flask, render_template, request
from utils.gemini_handler import analyze_with_gemini
from utils.youtube_handler import fetch_youtube_videos

app = Flask(__name__)

QUESTIONS = [
    "Do you enjoy working with numbers and solving mathematical problems?",
    "Are you interested in creative activities like painting, writing, or music?",
    "Do you like helping others and solving social or community issues?",
    "Are you comfortable working with technology and learning new software?",
    "Do you enjoy analyzing data and finding patterns or trends?",
    "Are you good at communicating and working with people in a team?",
    "Do you prefer working independently rather than in a group?",
    "Are you interested in science, medicine, or healthcare?",
    "Do you enjoy planning and organizing events or projects?",
    "Are you passionate about environmental issues and sustainability?",
    "Do you enjoy taking risks and trying new things?",
    "Are you more of a logical thinker than an emotional one?",
    "Do you value job stability and a predictable routine?",
    "Are you interested in business, finance, or entrepreneurship?",
    "Do you enjoy researching and exploring new ideas or concepts?"
]

@app.route('/')
def index():
    return render_template('index.html', questions=QUESTIONS)

@app.route('/result', methods=['POST'])
def result():
    responses = [request.form.get(f'q{i}') for i in range(1, 16)]
    analysis, careers, videos, certs = analyze_with_gemini(responses)
    video_embeds = fetch_youtube_videos(videos)
    return render_template('result.html', analysis=analysis, careers=careers, certs=certs, videos=video_embeds)

if __name__ == '__main__':
    app.run(debug=True)
