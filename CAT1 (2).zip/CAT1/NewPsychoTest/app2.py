import gradio as gr
import google.generativeai as genai
from googleapiclient.discovery import build
import re

# 🔑 Configure API Keys
GEMINI_API_KEY = "AIzaSyAYTiq4SUtBfJXKa05pO6xFOgWWRvbTzEs"
YOUTUBE_API_KEY = "AIzaSyBWGhudkQ0v5iCTxEGBV6uFUXDBsBlwfuM"

# 🔧 Setup Gemini
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-1.5-flash')

# 🔧 Setup YouTube API
def fetch_youtube_videos(query, max_results=2):
    youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)
    request = youtube.search().list(
        part="snippet",
        q=query,
        type="video",
        maxResults=max_results
    )
    response = request.execute()
    
    video_embeds = []
    for item in response["items"]:
        video_id = item["id"]["videoId"]
        video_url = f"https://www.youtube.com/embed/{video_id}"
        iframe = f"<iframe width='100%' height='250' src='{video_url}' frameborder='0' allowfullscreen></iframe>"
        video_embeds.append(iframe)
    
    return video_embeds

# ✅ Psychometric Questions
QUESTIONS = [
    {"id": 1, "text": "Do you enjoy working with numbers and solving mathematical problems?", "options": ["Yes", "No"]},
    {"id": 2, "text": "Are you interested in creative activities like painting, writing, or music?", "options": ["Yes", "No"]},
    {"id": 3, "text": "Do you like helping others and solving social or community issues?", "options": ["Yes", "No"]},
    {"id": 4, "text": "Are you comfortable working with technology and learning new software?", "options": ["Yes", "No"]},
    {"id": 5, "text": "Do you enjoy analyzing data and finding patterns or trends?", "options": ["Yes", "No"]},
    {"id": 6, "text": "Are you good at communicating and working with people in a team?", "options": ["Yes", "No"]},
    {"id": 7, "text": "Do you prefer working independently rather than in a group?", "options": ["Yes", "No"]},
    {"id": 8, "text": "Are you interested in science, medicine, or healthcare?", "options": ["Yes", "No"]},
    {"id": 9, "text": "Do you enjoy planning and organizing events or projects?", "options": ["Yes", "No"]},
    {"id": 10, "text": "Are you passionate about environmental issues and sustainability?", "options": ["Yes", "No"]},
    {"id": 11, "text": "Do you enjoy taking risks and trying new things?", "options": ["Yes", "No"]},
    {"id": 12, "text": "Are you more of a logical thinker than an emotional one?", "options": ["Yes", "No"]},
    {"id": 13, "text": "Do you value job stability and a predictable routine?", "options": ["Yes", "No"]},
    {"id": 14, "text": "Are you interested in business, finance, or entrepreneurship?", "options": ["Yes", "No"]},
    {"id": 15, "text": "Do you enjoy researching and exploring new ideas or concepts?", "options": ["Yes", "No"]},
]

# 🔎 Analyze with Gemini
def analyze_responses(*responses):
    input_text = "User responses to the psychometric test:\n"
    for i, response in enumerate(responses):
        input_text += f"Q{i+1}: {response}\n"

    prompt = f"""
    Based on the user's responses to a career psychometric test:
    {input_text}

    1. Analyze the user's personality and interests.
    2. Suggest 3 career paths with explanations.
    3. Recommend 2 YouTube video titles (no links needed).
    4. Suggest 1 free certification (e.g., NPTEL, Coursera) and 1 live course (e.g., Udemy) for each.

    Format:
    - Career 1: ...
    - Career 2: ...
    """

    response = model.generate_content(prompt)
    return response.text

# 🧠 Full Analysis
def full_analysis(*responses):
    result = analyze_responses(*responses)

    # Extract first suggested career title
    match = re.search(r"- Career 1:\s*(.*)", result)
    keyword = match.group(1).strip() if match else "career development"

    # Fetch YouTube videos
    video_embeds = fetch_youtube_videos(keyword)
    vid1 = video_embeds[0] if len(video_embeds) > 0 else ""
    vid2 = video_embeds[1] if len(video_embeds) > 1 else ""

    # Extract certifications
    cert_lines = "\n".join([line for line in result.split("\n") if "coursera" in line.lower() or "udemy" in line.lower() or "nptel" in line.lower() or "edx" in line.lower()])

    return result, vid1, vid2, cert_lines

# 🌐 Gradio Interface
with gr.Blocks(title="CareerCraft AI - Career Guidance Test") as demo:
    gr.Markdown("# 🎯 CareerCraft AI\nDiscover your ideal career path based on your interests and personality.")

    with gr.Row():
        with gr.Column(scale=1):
            gr.Markdown("### 📝 Answer all 15 questions:")
            responses = []
            for q in QUESTIONS:
                inp = gr.Radio(label=q["text"], choices=q["options"])
                responses.append(inp)
            submit_btn = gr.Button("🔍 Analyze & Suggest Careers")

        with gr.Column(scale=2):
            output_box = gr.Textbox(label="🧠 Gemini Career Suggestions", lines=20)
            gr.Markdown("### 🎥 Career Videos")
            video_frame_1 = gr.HTML()
            video_frame_2 = gr.HTML()
            gr.Markdown("### 📚 Certifications & Courses")
            certification_box = gr.Textbox(label="Courses & Certifications", lines=10)

    submit_btn.click(fn=full_analysis, inputs=responses, outputs=[output_box, video_frame_1, video_frame_2, certification_box])

demo.launch()
