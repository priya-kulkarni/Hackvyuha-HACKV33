import gradio as gr
import google.generativeai as genai

# Configure Gemini API
GEMINI_API_KEY = "AIzaSyAYTiq4SUtBfJXKa05pO6xFOgWWRvbTzEs"  # Replace with your actual API key
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-1.5-flash')

# Questions
QUESTIONS = [
    "Do you enjoy working with numbers and solving mathematical problems?",
    "Are you interested in creative activities like painting, writing, or music?",
    "Do you like helping others and solving social or community issues?",
    "Are you comfortable working with technology and learning new software?",
    "Do you enjoy analyzing data and finding patterns or trends?",
    "Are you good at communicating and working with people in a team?",
    "Do you prefer working independently rather than in a group?",
    "Are you interested in science, medicine, or healthcare?",
    "Do you enjoy planning and organizing events or projects?",
    "Are you passionate about environmental issues and sustainability?",
    "Do you enjoy taking risks and trying new things?",
    "Are you more of a logical thinker than an emotional one?",
    "Do you value job stability and a predictable routine?",
    "Are you interested in business, finance, or entrepreneurship?",
    "Do you enjoy researching and exploring new ideas or concepts?"
]

def analyze_responses(*responses):
    input_text = "User responses to the psychometric test:\n"
    for i, response in enumerate(responses):
        input_text += f"Q{i+1}: {response}\n"

    prompt = f"""
    Based on the user's responses to a career psychometric test:
    {input_text}

    1. Analyze the user's personality and interests.
    2. Suggest 3 career paths with explanations.
    3. Recommend 2 YouTube video titles (include video URLs) for each career.
    4. Suggest 1 free certification (e.g., NPTEL, Coursera) and 1 live course (e.g., Udemy) for each.

    Respond in structured format like:
    - Career 1:
        - Description
        - YouTube: [Title](url)
        - Certification: Name (URL)
        - Live Course: Name (URL)
    """

    response = model.generate_content(prompt)
    return response.text

with gr.Blocks(title="CareerCraft AI - Psychometric Career Guide") as demo:
    
    # Embedded CSS
    gr.HTML("""
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #eef2f3, #8e9eab);
            margin: 0;
        }
        h1, h2, h3 {
            color: #2c3e50;
        }
        .output-box {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .iframe-container iframe {
            border-radius: 8px;
            margin-bottom: 10px;
        }
    </style>
    """)

    gr.HTML("<h1>🎯 CareerCraft AI</h1><p>Discover your ideal career based on your interests and personality traits.</p>")

    with gr.Row():
        with gr.Column(scale=1):
            gr.HTML("<h3>📝 Answer all 15 questions:</h3>")

            # Create inputs dynamically inside the layout
            inputs = []
            for q in QUESTIONS:
                radio = gr.Radio(choices=["Yes", "No"], label=q)
                inputs.append(radio)

            submit_btn = gr.Button("🔍 Analyze and Suggest Careers")

        with gr.Column(scale=2):
            output_box = gr.Textbox(label="🧠 Gemini Career Suggestions", lines=20, elem_classes="output-box")
            gr.Markdown(" 🎥 Recommended Career Videos")
            video_frame_1 = gr.HTML()
            video_frame_2 = gr.HTML()
            gr.Markdown(" 📚 Suggested Certifications and Courses")
            certification_box = gr.Textbox(label="Courses & Certifications", lines=10)

    def full_analysis(*responses):
        result = analyze_responses(*responses)

        # Parse YouTube links
        video_urls = []
        for line in result.split("\n"):
            if "youtube.com" in line:
                video_urls.append(line.split("(")[-1].strip(")"))

        # Embed videos
        vid1 = f"<iframe width='100%' height='250' src='{video_urls[0]}' frameborder='0' allowfullscreen></iframe>" if len(video_urls) > 0 else ""
        vid2 = f"<iframe width='100%' height='250' src='{video_urls[1]}' frameborder='0' allowfullscreen></iframe>" if len(video_urls) > 1 else ""

        # Extract certifications
        cert_lines = "\n".join([line for line in result.split("\n") if any(k in line.lower() for k in ["coursera", "udemy", "nptel", "edx"])])

        return result, vid1, vid2, cert_lines

    submit_btn.click(fn=full_analysis, inputs=inputs, outputs=[output_box, video_frame_1, video_frame_2, certification_box])

demo.launch()
