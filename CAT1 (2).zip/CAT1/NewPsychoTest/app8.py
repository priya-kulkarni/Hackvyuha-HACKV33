import gradio as gr
import google.generativeai as genai
import re
import requests

# Configure Gemini API
GEMINI_API_KEY = "AIzaSyAYTiq4SUtBfJXKa05pO6xFOgWWRvbTzEs"
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-1.5-flash')

# JSearch API Configuration
JSEARCH_API_URL = "https://jsearch.p.rapidapi.com/search"
JSEARCH_API_KEY = "bcc95e5f07mshf7a2b7f196850f9p1a7083jsn1c7db82afd20"

# Configure YouTube API
YOUTUBE_API_KEY = "AIzaSyBWGhudkQ0v5iCTxEGBV6uFUXDBsBlwfuM"

# Questions
QUESTIONS = [
    "Do you enjoy working with numbers and solving mathematical problems?",
    "Are you interested in creative activities like painting, writing, or music?",
    "Do you like helping others and solving social or community issues?",
    "Are you comfortable working with technology and learning new software?",
    "Do you enjoy analyzing data and finding patterns or trends?",
    "Are you good at communicating and working with people in a team?",
    "Do you prefer working independently rather than in a group?",
    "Are you interested in science, medicine, or healthcare?",
    "Do you enjoy planning and organizing events or projects?",
    "Are you passionate about environmental issues and sustainability?",
    "Do you enjoy taking risks and trying new things?",
    "Are you more of a logical thinker than an emotional one?",
    "Do you value job stability and a predictable routine?",
    "Are you interested in business, finance, or entrepreneurship?",
    "Do you enjoy researching and exploring new ideas or concepts?"
]

def clean_formatting(text):
    """Removes unnecessary formatting like ***."""
    return re.sub(r"\*+", "", text)

def analyze_responses(*responses):
    input_text = "User responses to the psychometric test:\n"
    for i, response in enumerate(responses):
        input_text += f"Q{i+1}: {response}\n"

    prompt = f"""
    Based on the user's responses to a career psychometric test:
    {input_text}

    1. Analyze the user's personality and interests.
    2. Suggest 3 career paths with explanations.
    3. Recommend 2 YouTube video titles for each career.
    4. Suggest 3 certification courses (with links).

    Respond in structured format like:
    - Career 1:
        - Description
        - YouTube: Title 1; Title 2
        - Certification: [Course 1](URL1), [Course 2](URL2), [Course 3](URL3)
    """

    response = model.generate_content(prompt)
    return clean_formatting(response.text)

def search_youtube_videos(query):
    """Fetch YouTube videos based on query."""
    url = "https://www.googleapis.com/youtube/v3/search"
    params = {
        "part": "snippet",
        "q": query,
        "type": "video",
        "maxResults": 3,
        "key": YOUTUBE_API_KEY
    }
    response = requests.get(url, params=params)
    data = response.json()

    video_iframes = [
        f"""
        <div class="video-item">
            <iframe width='100%' height='200' src='https://www.youtube.com/embed/{item['id']['videoId']}' frameborder='0' allowfullscreen></iframe>
        </div>
        """
        for item in data.get("items", [])
    ]
    return "".join(video_iframes)

def full_analysis(*responses):
    result = analyze_responses(*responses)
    careers = re.findall(r"- Career \d+: (.+)", result)
    career_suggestions = ", ".join(careers) if careers else "Software Engineer, Data Scientist, Project Manager"
    return result, career_suggestions

def get_resources(career_suggestions):
    """Fetch YouTube videos and other resources."""
    careers = career_suggestions.split(", ")
    youtube_videos = []
    for career in careers:
        video_iframes = search_youtube_videos(career)
        youtube_videos.append(video_iframes)

    videos_html = "".join(youtube_videos)

    # Certifications (Static for now)
    certifications = """
        <div><a href='https://www.coursera.org/' target='_blank'>Coursera</a></div>
        <div><a href='https://www.udemy.com/' target='_blank'>Udemy</a></div>
        <div><a href='https://www.edx.org/' target='_blank'>edX</a></div>
    """

    # Jobs (Static for now)
    job_links = """
        <div><a href='https://www.indeed.com/' target='_blank'>Indeed</a></div>
        <div><a href='https://www.linkedin.com/jobs/' target='_blank'>LinkedIn Jobs</a></div>
        <div><a href='https://www.glassdoor.com/' target='_blank'>Glassdoor</a></div>
    """

    return f"<div class='video-grid'>{videos_html}</div>", certifications, job_links

with gr.Blocks(title="CareerCraft AI - Enhanced Layout") as demo:
    gr.HTML("""
        <style>
            body {
                font-family: 'Arial', sans-serif;
                background-color: #f0f2f5;
                padding: 20px;
            }
            .container {
                max-width: 1200px;
                margin: 0 auto;
                background-color: #fff;
                padding: 20px;
                border-radius: 12px;
                box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            }
            .header {
                font-size: 24px;
                font-weight: bold;
                margin-bottom: 10px;
                color: #333;
            }
            .video-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
                gap: 20px;
                margin-top: 20px;
            }
            .video-item {
                background-color: #fafafa;
                padding: 10px;
                border-radius: 8px;
                box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
            }
        </style>
    """)

    gr.HTML("<div class='header'>🎯 CareerCraft AI - Discover Your Career Path</div>")

    with gr.Row():
        with gr.Column(scale=1):
            inputs = [gr.Radio(choices=["Yes", "No"], label=q) for q in QUESTIONS]
            submit_btn = gr.Button("Analyze and Suggest Careers")

        with gr.Column(scale=2):
            output_box = gr.Textbox(label="Career Suggestions", lines=10)
            youtube_section = gr.HTML()
            certification_section = gr.HTML()
            job_section = gr.HTML()

    career_state = gr.State("")

    def update_resources(career_suggestions):
        videos_html, certifications, job_links = get_resources(career_suggestions)
        return videos_html, certifications, job_links

    submit_btn.click(
        fn=full_analysis,
        inputs=inputs,
        outputs=[output_box, career_state]
    )

    youtube_section.click(
        fn=lambda cs: update_resources(cs)[0],
        inputs=career_state,
        outputs=youtube_section
    )

    certification_section.click(
        fn=lambda cs: update_resources(cs)[1],
        inputs=career_state,
        outputs=certification_section
    )

    job_section.click(
        fn=lambda cs: update_resources(cs)[2],
        inputs=career_state,
        outputs=job_section
    )

demo.launch()
