import gradio as gr
import google.generativeai as genai
import re
import requests

# Configure Gemini API
GEMINI_API_KEY = "AIzaSyAYTiq4SUtBfJXKa05pO6xFOgWWRvbTzEs"
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-1.5-flash')

# Configure YouTube API
YOUTUBE_API_KEY = "AIzaSyBWGhudkQ0v5iCTxEGBV6uFUXDBsBlwfuM"

# Questions
QUESTIONS = [
    "Do you enjoy working with numbers and solving mathematical problems?",
    "Are you interested in creative activities like painting, writing, or music?",
    "Do you like helping others and solving social or community issues?",
    "Are you comfortable working with technology and learning new software?",
    "Do you enjoy analyzing data and finding patterns or trends?",
    "Are you good at communicating and working with people in a team?",
    "Do you prefer working independently rather than in a group?",
    "Are you interested in science, medicine, or healthcare?",
    "Do you enjoy planning and organizing events or projects?",
    "Are you passionate about environmental issues and sustainability?",
    "Do you enjoy taking risks and trying new things?",
    "Are you more of a logical thinker than an emotional one?",
    "Do you value job stability and a predictable routine?",
    "Are you interested in business, finance, or entrepreneurship?",
    "Do you enjoy researching and exploring new ideas or concepts?"
]

def clean_formatting(text):
    """Removes unnecessary formatting like ***."""
    return re.sub(r"\*+", "", text)

def analyze_responses(*responses):
    input_text = "User responses to the psychometric test:\n"
    for i, response in enumerate(responses):
        input_text += f"Q{i+1}: {response}\n"

    prompt = f"""
    Based on the user's responses to a career psychometric test:
    {input_text}

    1. Analyze the user's personality and interests.
    2. Suggest 3 career paths with explanations.
    3. Recommend 2 YouTube video titles for each career.

    Respond in structured format like:
    - Career 1:
        - Description
        - YouTube: Title 1; Title 2
    """

    response = model.generate_content(prompt)
    return clean_formatting(response.text)

def search_youtube_videos(query):
    """Fetch YouTube videos based on query."""
    url = "https://www.googleapis.com/youtube/v3/search"
    params = {
        "part": "snippet",
        "q": query,
        "type": "video",
        "maxResults": 10,
        "key": YOUTUBE_API_KEY
    }
    response = requests.get(url, params=params)
    data = response.json()

    video_urls = [
        f"https://www.youtube.com/embed/{item['id']['videoId']}"
        for item in data.get("items", [])
    ]
    return video_urls

def full_analysis(*responses):
    result = analyze_responses(*responses)

    # Extract YouTube suggestions
    video_titles = re.findall(r"- YouTube: (.+?); (.+)", result)
    search_queries = [title for pair in video_titles for title in pair]

    if not search_queries:
        search_queries = ["Career Guidance", "Data Analysis", "Software Development"]

    # Fetch videos from YouTube
    video_frames = []
    for query in search_queries:
        video_urls = search_youtube_videos(query)
        for url in video_urls:
            video_frames.append(f"""
                <div style="margin-bottom: 20px;">
                    <iframe width='100%' height='250' src='{url}' frameborder='0' allowfullscreen></iframe>
                </div>
            """)

    return result, video_frames[:3], video_frames

with gr.Blocks(title="CareerCraft AI - Psychometric Career Guide") as demo:
    gr.HTML("""
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #eef2f3, #8e9eab);
            margin: 0;
        }
        .output-box {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .iframe-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
    </style>
    """)

    gr.HTML("<h1>🎯 CareerCraft AI</h1><p>Discover your ideal career based on your interests and personality traits.</p>")

    with gr.Row():
        with gr.Column(scale=1):
            gr.HTML("<h3>📝 Answer all 15 questions:</h3>")
            inputs = [gr.Radio(choices=["Yes", "No"], label=q) for q in QUESTIONS]
            submit_btn = gr.Button("🔍 Analyze and Suggest Careers")

        with gr.Column(scale=2):
            output_box = gr.Textbox(label="🧠 Gemini Career Suggestions", lines=10, elem_classes="output-box")
            video_section = gr.HTML()
            next_btn = gr.Button("Next ➡️")
            prev_btn = gr.Button("⬅️ Previous")
    
    video_state = gr.State([])  # Store video frames
    index_state = gr.State(0)   # Track current index

    def update_videos(video_list, index):
        """Paginate videos to show 3 per page."""
        start = index * 3
        end = start + 3
        current_videos = video_list[start:end]
        return "".join(current_videos), video_list, index

    def next_page(video_list, index):
        """Navigate to the next page."""
        index += 1
        return update_videos(video_list, index)

    def prev_page(video_list, index):
        """Navigate to the previous page."""
        index = max(0, index - 1)
        return update_videos(video_list, index)

    submit_btn.click(fn=full_analysis, inputs=inputs, outputs=[output_box, video_section, video_state])
    next_btn.click(fn=next_page, inputs=[video_state, index_state], outputs=[video_section, video_state, index_state])
    prev_btn.click(fn=prev_page, inputs=[video_state, index_state], outputs=[video_section, video_state, index_state])

demo.launch()
